# 🎓 Greenfield University Academic Assistant

> A complete, production-quality **RAG (Retrieval-Augmented Generation)** AI assistant that answers student questions using official university documents — grounded, cited, and never fabricating regulations.

---

## ✨ Features

| Feature | Details |
|---|---|
| 🔍 **Semantic Search** | `sentence-transformers/all-MiniLM-L6-v2` embeddings |
| 🗄️ **Vector Store** | ChromaDB (local, persistent, zero-config) |
| 🤖 **LLM** | Google Gemini 2.0 Flash |
| 📎 **Source Citations** | Every answer shows which document & relevance score |
| 🛡️ **Hallucination Guard** | Model instructed to say "not found" if info absent |
| 🎨 **Rich UI** | Vanilla JS chat with sidebar, confidence badges, doc viewer |
| 📤 **Document Upload** | Upload new `.txt`/`.pdf` docs at runtime |
| 💬 **Conversation History** | Multi-turn context (last 4 exchanges) |
| ⚡ **FastAPI Backend** | Async REST API with CORS support |

---

## 🏗️ Architecture

```
Student Question
      │
      ▼
 ┌─────────────┐        ┌──────────────────────────────┐
 │  FastAPI    │        │    ChromaDB Vector Store      │
 │  /api/chat  │──────▶ │   5 university documents      │
 └─────────────┘  query │   ~200+ embedded chunks       │
      │          embed  └──────────────────────────────┘
      │          results        │ Top-K chunks
      │◀────────────────────────┘
      │
      ▼
 ┌─────────────────────────────────────────┐
 │   Gemini 2.0 Flash                      │
 │   Prompt = System + Context + Question  │
 │   "Answer ONLY from provided excerpts"  │
 └─────────────────────────────────────────┘
      │
      ▼
 Answer + Sources + Confidence Score
```

---

## 📁 Project Structure

```
uni-assistant/
├── backend/
│   ├── main.py              ← FastAPI server + RAG engine
│   ├── chroma_db/           ← Persistent vector database (auto-created)
│   └── data/
│       ├── academic_regulations.txt
│       ├── examination_guidelines.txt
│       ├── attendance_policy.txt
│       ├── academic_calendar.txt
│       ├── course_regulations.txt
│       ├── financial_aid_handbook.txt
│       └── student_conduct_rights.txt
├── frontend/
│   └── index.html           ← Full chat UI (no framework dependencies)
├── start.py                 ← Convenience startup script
├── test_rag.py              ← End-to-end pipeline smoke test
└── README.md
```

---

## 🚀 Quick Start

### 1. Get a Gemini API Key
Go to [Google AI Studio](https://aistudio.google.com/) → Create API Key (free tier available)

### 2. Start the Server

**Option A — Pass key directly:**
```powershell
cd d:\prompt\uni-assistant
python start.py --api-key YOUR_GEMINI_API_KEY
```

**Option B — Set environment variable first:**
```powershell
$env:GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"
python start.py
```

**Option C — Retrieval-only mode (no LLM, no key needed):**
```powershell
python start.py
```
*(The system will still retrieve and show relevant document excerpts)*

### 3. Open Your Browser
Navigate to → **http://localhost:8000**

The browser opens automatically after 3 seconds.

---

## 🧪 Testing the Pipeline

```powershell
cd d:\prompt\uni-assistant
python test_rag.py                                    # Retrieval test
python test_rag.py  # with GEMINI_API_KEY set → full test
```

---

## 📚 Indexed Documents

| Document | Contents |
|---|---|
| `academic_regulations.txt` | GPA rules, probation, grading scale, honors, degree requirements |
| `examination_guidelines.txt` | Exam conduct, late arrivals, accommodations, malpractice |
| `attendance_policy.txt` | Minimum attendance, excused absences, DN grade consequences |
| `academic_calendar.txt` | Fall/Spring 2024-25 dates, registration windows, holidays |
| `course_regulations.txt` | Credit hours, assessment breakdown, withdrawal, incomplete grades |
| `financial_aid_handbook.txt` | Pell Grant, loans, scholarships, SAP requirements |
| `student_conduct_rights.txt` | Rights, conduct code, grievance procedures, FERPA |

---

## ➕ Adding Your Own Documents

**Via the UI:** Click **"+ Upload Document"** in the sidebar → select `.txt` file → auto-indexed.

**Via the API:**
```bash
curl -X POST http://localhost:8000/api/upload \
  -F "file=@your_policy.txt"
```

**Drop files manually:** Place `.txt` or `.pdf` files in `backend/data/` → call `POST /api/ingest`.

---

## 🌐 API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/status` | System health + collection stats |
| `POST` | `/api/chat` | Ask a question (RAG pipeline) |
| `GET` | `/api/documents` | List indexed documents |
| `POST` | `/api/upload` | Upload a new document |
| `POST` | `/api/ingest` | Re-ingest all files from `/data` |
| `GET` | `/api/sample-questions` | Curated starter questions |

**Chat request body:**
```json
{
  "question": "What is the minimum GPA for good standing?",
  "conversation_history": [
    { "role": "user", "content": "previous question" },
    { "role": "assistant", "content": "previous answer" }
  ]
}
```

---

## ⚙️ Configuration

Edit these constants in `backend/main.py`:

```python
EMBEDDING_MODEL    = "all-MiniLM-L6-v2"  # HuggingFace model
CHUNK_SIZE         = 800    # chars per chunk
CHUNK_OVERLAP      = 150    # overlap between chunks
TOP_K_RESULTS      = 5      # chunks retrieved per query
MIN_RELEVANCE_SCORE = 0.3   # cosine similarity floor (0–1)
```

---

## 🛡️ Design Principles

1. **No Hallucinations** — The system prompt explicitly forbids the LLM from answering beyond retrieved context
2. **Source Transparency** — Every answer shows exact source documents and relevance scores  
3. **Graceful Degradation** — Works without an API key in retrieval-only mode
4. **Idempotent Ingestion** — Re-ingesting the same document is safe (uses content hashes)
5. **Persistent Storage** — ChromaDB writes to disk; survives server restarts

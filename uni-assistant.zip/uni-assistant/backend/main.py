"""
Greenfield University Academic Assistant - RAG Backend
======================================================
FastAPI server with ChromaDB vector store and Google Gemini LLM.
"""

import os
import re
import json
import uuid
import glob
import hashlib
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

# Load .env file if present
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env")
except ImportError:
    pass

import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
from google import genai
from google.genai import types as genai_types

from fastapi import FastAPI, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

# ─────────────────────────── Configuration ───────────────────────────────────

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
CHROMA_DIR = BASE_DIR / "chroma_db"
FRONTEND_DIR = BASE_DIR.parent / "frontend"

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
COLLECTION_NAME = "university_docs"
CHUNK_SIZE = 800          # characters per chunk
CHUNK_OVERLAP = 150       # overlap between consecutive chunks
TOP_K_RESULTS = 5         # number of chunks to retrieve
MIN_RELEVANCE_SCORE = 0.3  # cosine distance threshold (lower = more similar)
GEMINI_MODEL_NAME = "models/gemini-2.5-flash"

# ─────────────────────────── Pydantic Models ─────────────────────────────────

class ChatRequest(BaseModel):
    question: str
    conversation_history: Optional[List[Dict[str, str]]] = []

class ChatResponse(BaseModel):
    answer: str
    sources: List[Dict[str, Any]]
    confidence: str
    retrieved_chunks: int
    timestamp: str

class IngestStatus(BaseModel):
    status: str
    message: str
    documents_indexed: int
    chunks_created: int

class StatusResponse(BaseModel):
    status: str
    documents_count: int
    chunks_count: int
    embedding_model: str
    llm_model: str
    api_configured: bool

# ─────────────────────────── RAG Engine ──────────────────────────────────────

class UniversityRAGEngine:
    """Core RAG engine: embed → store → retrieve → generate."""

    def __init__(self):
        self.embedder: Optional[SentenceTransformer] = None
        self.chroma_client: Optional[chromadb.PersistentClient] = None
        self.collection = None
        self.gemini_client = None
        self.gemini_model = None
        self.initialized = False
        self.doc_registry: Dict[str, str] = {}  # filename → doc_id mapping

    def initialize(self):
        """Load models and connect to vector store."""
        logger.info("Initializing RAG engine…")

        # 1. Embedding model
        logger.info(f"Loading embedding model: {EMBEDDING_MODEL}")
        self.embedder = SentenceTransformer(EMBEDDING_MODEL)

        # 2. ChromaDB persistent client
        CHROMA_DIR.mkdir(parents=True, exist_ok=True)
        self.chroma_client = chromadb.PersistentClient(
            path=str(CHROMA_DIR),
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = self.chroma_client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

        # 3. Gemini LLM (google-genai SDK)
        if GEMINI_API_KEY:
            self.gemini_client = genai.Client(api_key=GEMINI_API_KEY)
            self.gemini_model = GEMINI_MODEL_NAME
            logger.info(f"Gemini client configured ({GEMINI_MODEL_NAME}).")
        else:
            self.gemini_client = None
            self.gemini_model = None
            logger.warning("GEMINI_API_KEY not set — LLM answers will be disabled.")

        self.initialized = True
        logger.info(f"RAG engine ready. Collection has {self.collection.count()} chunks.")

    # ──────────────────── Document Ingestion ─────────────────────────────────

    def chunk_text(self, text: str, source: str) -> List[Dict[str, str]]:
        """Split text into overlapping chunks."""
        # Normalize whitespace
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        chunks = []
        start = 0
        while start < len(text):
            end = start + CHUNK_SIZE
            chunk = text[start:end]
            # Try to break at a sentence boundary
            if end < len(text):
                last_period = chunk.rfind(". ")
                last_newline = chunk.rfind("\n")
                break_at = max(last_period, last_newline)
                if break_at > CHUNK_SIZE // 2:
                    chunk = text[start : start + break_at + 1]
                    end = start + break_at + 1
            chunks.append({
                "text": chunk.strip(),
                "source": source,
                "chunk_index": len(chunks),
            })
            start = end - CHUNK_OVERLAP
        return [c for c in chunks if len(c["text"]) > 50]

    def ingest_file(self, file_path: Path) -> Dict[str, int]:
        """Read, chunk, embed and upsert a single document."""
        filename = file_path.name
        content = file_path.read_text(encoding="utf-8", errors="ignore")

        chunks = self.chunk_text(content, filename)
        if not chunks:
            return {"chunks": 0}

        texts = [c["text"] for c in chunks]
        embeddings = self.embedder.encode(texts, show_progress_bar=False).tolist()

        ids, docs, embeds, metas = [], [], [], []
        for i, (chunk, emb) in enumerate(zip(chunks, embeddings)):
            # Deterministic ID so re-ingesting is idempotent
            chunk_id = hashlib.md5(f"{filename}_{i}_{chunk['text'][:40]}".encode()).hexdigest()
            ids.append(chunk_id)
            docs.append(chunk["text"])
            embeds.append(emb)
            metas.append({
                "source": filename,
                "chunk_index": i,
                "total_chunks": len(chunks),
                "file_path": str(file_path),
            })

        # Upsert (handles duplicates gracefully)
        self.collection.upsert(
            ids=ids,
            documents=docs,
            embeddings=embeds,
            metadatas=metas,
        )
        logger.info(f"Ingested '{filename}': {len(chunks)} chunks.")
        return {"chunks": len(chunks)}

    def ingest_directory(self, directory: Path) -> IngestStatus:
        """Ingest all .txt and .pdf files in a directory."""
        files = list(directory.glob("*.txt")) + list(directory.glob("*.pdf"))
        if not files:
            return IngestStatus(status="ok", message="No documents found.", documents_indexed=0, chunks_created=0)

        total_chunks = 0
        for fp in files:
            result = self.ingest_file(fp)
            total_chunks += result["chunks"]

        return IngestStatus(
            status="ok",
            message=f"Successfully indexed {len(files)} document(s).",
            documents_indexed=len(files),
            chunks_created=total_chunks,
        )

    # ──────────────────── Retrieval ──────────────────────────────────────────

    def retrieve(self, query: str, top_k: int = TOP_K_RESULTS) -> List[Dict[str, Any]]:
        """Embed query and retrieve top-K most relevant chunks."""
        if self.collection.count() == 0:
            return []

        query_embedding = self.embedder.encode([query]).tolist()
        results = self.collection.query(
            query_embeddings=query_embedding,
            n_results=min(top_k, self.collection.count()),
            include=["documents", "metadatas", "distances"],
        )

        retrieved = []
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            relevance = 1.0 - dist   # cosine distance → similarity score
            if relevance < MIN_RELEVANCE_SCORE:
                continue
            retrieved.append({
                "text": doc,
                "source": meta["source"],
                "chunk_index": meta.get("chunk_index", 0),
                "relevance_score": round(relevance, 4),
            })

        # Sort by relevance descending
        retrieved.sort(key=lambda x: x["relevance_score"], reverse=True)
        return retrieved

    # ──────────────────── Answer Generation ──────────────────────────────────

    def build_prompt(self, question: str, context_chunks: List[Dict], history: List[Dict]) -> str:
        """Build the RAG prompt combining context + conversation history."""
        context_sections = []
        for i, chunk in enumerate(context_chunks, 1):
            context_sections.append(
                f"[Source {i}: {chunk['source']} | Relevance: {chunk['relevance_score']:.2f}]\n{chunk['text']}"
            )
        context_text = "\n\n---\n\n".join(context_sections)

        history_text = ""
        if history:
            history_lines = []
            for turn in history[-4:]:  # Last 4 turns for context
                role = "Student" if turn.get("role") == "user" else "Assistant"
                history_lines.append(f"{role}: {turn['content']}")
            history_text = "\n".join(history_lines)

        prompt = f"""You are the official Academic Assistant for Greenfield University. Your role is to help students understand university policies, regulations, and procedures by answering questions accurately based ONLY on the official university documents provided below.

CRITICAL RULES:
1. Answer ONLY based on the provided document excerpts. Do NOT invent, assume, or extrapolate beyond what is explicitly stated.
2. If the answer is not in the provided excerpts, clearly state: "I could not find this information in the available university documents. Please contact the relevant office directly."
3. Always cite your sources using the [Source N] tags provided.
4. Be precise about numbers (dates, percentages, credit hours, GPA thresholds, etc.).
5. Use clear, professional language appropriate for a university setting.
6. If a policy has nuances or exceptions, mention them clearly.

OFFICIAL DOCUMENT EXCERPTS:
{context_text}

{"CONVERSATION HISTORY:" + chr(10) + history_text if history_text else ""}

STUDENT QUESTION: {question}

ANSWER (cite sources where applicable):"""
        return prompt

    def generate_answer(self, question: str, context_chunks: List[Dict], history: List[Dict]) -> str:
        """Call Gemini to generate the answer."""
        if not self.gemini_client or not self.gemini_model:
            return (
                "The AI language model is not configured. "
                "Please set the GEMINI_API_KEY environment variable and restart the server. "
                "However, I was able to retrieve relevant document sections - see the Sources panel."
            )

        if not context_chunks:
            return (
                "I could not find any relevant information in the university documents for your question. "
                "Please try rephrasing your question, or contact the appropriate university office directly."
            )

        prompt = self.build_prompt(question, context_chunks, history)
        try:
            response = self.gemini_client.models.generate_content(
                model=self.gemini_model,
                contents=prompt,
                config=genai_types.GenerateContentConfig(
                    temperature=0.1,
                    max_output_tokens=1024,
                ),
            )
            return response.text.strip()
        except Exception as e:
            logger.error(f"Gemini API error: {e}")
            return f"An error occurred while generating the answer: {str(e)}"

    def assess_confidence(self, chunks: List[Dict]) -> str:
        """Simple confidence assessment based on retrieval scores."""
        if not chunks:
            return "none"
        avg_score = sum(c["relevance_score"] for c in chunks) / len(chunks)
        top_score = chunks[0]["relevance_score"] if chunks else 0
        if top_score >= 0.75 and avg_score >= 0.6:
            return "high"
        elif top_score >= 0.55:
            return "medium"
        else:
            return "low"

    def answer(self, question: str, history: List[Dict] = []) -> ChatResponse:
        """Full RAG pipeline: retrieve → generate → respond."""
        chunks = self.retrieve(question)
        answer_text = self.generate_answer(question, chunks, history)
        confidence = self.assess_confidence(chunks)

        sources = [
            {
                "source": c["source"],
                "text": c["text"][:300] + ("…" if len(c["text"]) > 300 else ""),
                "relevance_score": c["relevance_score"],
                "chunk_index": c["chunk_index"],
            }
            for c in chunks
        ]

        return ChatResponse(
            answer=answer_text,
            sources=sources,
            confidence=confidence,
            retrieved_chunks=len(chunks),
            timestamp=datetime.utcnow().isoformat() + "Z",
        )

    def get_status(self) -> StatusResponse:
        count = self.collection.count() if self.collection else 0
        # Approximate doc count from unique sources
        unique_sources = set()
        if count > 0:
            sample = self.collection.get(limit=count, include=["metadatas"])
            for m in sample["metadatas"]:
                unique_sources.add(m.get("source", ""))
        return StatusResponse(
            status="ready" if self.initialized else "initializing",
            documents_count=len(unique_sources),
            chunks_count=count,
            embedding_model=EMBEDDING_MODEL,
            llm_model="gemini-2.0-flash",
            api_configured=bool(GEMINI_API_KEY),
        )


# ─────────────────────────── FastAPI App ─────────────────────────────────────

app = FastAPI(
    title="Greenfield University Academic Assistant API",
    description="RAG-powered assistant for university policies and regulations.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

rag_engine = UniversityRAGEngine()


@app.on_event("startup")
async def startup_event():
    """Initialize RAG engine and auto-ingest documents on startup."""
    logger.info("Starting up Academic Assistant API…")
    rag_engine.initialize()

    # Auto-ingest all documents in /data directory
    if DATA_DIR.exists():
        txt_files = list(DATA_DIR.glob("*.txt"))
        if txt_files and rag_engine.collection.count() == 0:
            logger.info(f"Auto-ingesting {len(txt_files)} documents…")
            rag_engine.ingest_directory(DATA_DIR)
        else:
            logger.info(f"Collection already has {rag_engine.collection.count()} chunks; skipping auto-ingest.")


# ─── API Routes ──────────────────────────────────────────────────────────────

@app.get("/api/status", response_model=StatusResponse)
async def get_status():
    """Return system health and collection statistics."""
    if not rag_engine.initialized:
        raise HTTPException(status_code=503, detail="RAG engine is not yet initialized.")
    return rag_engine.get_status()


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Main chat endpoint — accepts a question, returns RAG-powered answer + sources."""
    if not rag_engine.initialized:
        raise HTTPException(status_code=503, detail="RAG engine is not yet initialized.")
    if not request.question.strip():
        raise HTTPException(status_code=400, detail="Question cannot be empty.")
    if len(request.question) > 2000:
        raise HTTPException(status_code=400, detail="Question too long (max 2000 characters).")

    return rag_engine.answer(request.question, request.conversation_history or [])


@app.post("/api/ingest", response_model=IngestStatus)
async def ingest_documents():
    """Re-ingest all documents from the /data directory."""
    if not rag_engine.initialized:
        raise HTTPException(status_code=503, detail="RAG engine is not yet initialized.")
    return rag_engine.ingest_directory(DATA_DIR)


@app.post("/api/upload")
async def upload_document(file: UploadFile = File(...)):
    """Upload and ingest a new .txt document."""
    if not rag_engine.initialized:
        raise HTTPException(status_code=503, detail="RAG engine is not yet initialized.")
    if not file.filename.endswith((".txt", ".pdf")):
        raise HTTPException(status_code=400, detail="Only .txt and .pdf files are supported.")

    content = await file.read()
    target = DATA_DIR / file.filename
    target.write_bytes(content)

    result = rag_engine.ingest_file(target)
    return {"status": "ok", "filename": file.filename, "chunks_created": result["chunks"]}


@app.get("/api/documents")
async def list_documents():
    """List all indexed documents."""
    if not rag_engine.initialized or not rag_engine.collection:
        return {"documents": []}
    count = rag_engine.collection.count()
    if count == 0:
        return {"documents": []}
    sample = rag_engine.collection.get(limit=count, include=["metadatas"])
    sources: Dict[str, int] = {}
    for m in sample["metadatas"]:
        src = m.get("source", "unknown")
        sources[src] = sources.get(src, 0) + 1
    docs = [{"filename": k, "chunks": v} for k, v in sorted(sources.items())]
    return {"documents": docs}


@app.get("/api/sample-questions")
async def sample_questions():
    """Return a curated list of sample questions to get started."""
    return {
        "questions": [
            "What is the minimum GPA to remain in good academic standing?",
            "What happens if I miss more than 25% of my classes?",
            "When can I withdraw from a course without it affecting my GPA?",
            "What are the requirements for making the Dean's List?",
            "How do I apply for an Incomplete grade?",
            "What is the penalty for submitting an assignment 48 hours late?",
            "When does Fall 2024 semester registration open for sophomores?",
            "What happens if I am caught cheating on an exam?",
            "How many credit hours do I need to be a senior?",
            "What is the maximum Pell Grant award for 2024-2025?",
            "Can I take more than 18 credit hours per semester?",
            "What are the graduation honor GPA thresholds?",
            "How long do I have to appeal a grade after it is posted?",
            "What happens to my scholarship if my GPA drops below the requirement?",
            "What are the rules for arriving late to an exam?",
        ]
    }


# Serve frontend static files
if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)

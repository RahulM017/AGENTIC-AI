#!/usr/bin/env python3
"""
Greenfield University Academic Assistant — Startup Script
=========================================================
Sets the API key and launches the FastAPI server.

Usage:
  python start.py [--api-key YOUR_GEMINI_KEY]

  Or set GEMINI_API_KEY environment variable before running.
"""

import os
import sys
import subprocess
import argparse
import webbrowser
import time

def main():
    parser = argparse.ArgumentParser(description="Start the University Academic Assistant")
    parser.add_argument("--api-key", help="Your Google Gemini API key")
    parser.add_argument("--port", type=int, default=8000, help="Server port (default: 8000)")
    parser.add_argument("--no-browser", action="store_true", help="Don't open browser automatically")
    args = parser.parse_args()

    # Set API key
    if args.api_key:
        os.environ["GEMINI_API_KEY"] = args.api_key
    elif not os.environ.get("GEMINI_API_KEY"):
        print("\n" + "="*60)
        print("  ⚠  GEMINI_API_KEY not set")
        print("="*60)
        print("  The assistant will work in retrieval-only mode.")
        print("  To enable AI-generated answers, run with:")
        print("    python start.py --api-key YOUR_KEY_HERE")
        print("  Or set the environment variable:")
        print("    $env:GEMINI_API_KEY = 'your-key'  (PowerShell)")
        print("="*60 + "\n")

    print("\n" + "="*60)
    print("  🎓  Greenfield University Academic Assistant")
    print("="*60)
    print(f"  🌐  URL: http://localhost:{args.port}")
    print(f"  📚  Data: ./backend/data/")
    print(f"  🗄️   Vector DB: ./backend/chroma_db/")
    print(f"  🤖  LLM: {'Gemini 2.0 Flash ✅' if os.environ.get('GEMINI_API_KEY') else 'Not configured ⚠️'}")
    print("="*60)
    print("  Press Ctrl+C to stop the server\n")

    backend_dir = os.path.join(os.path.dirname(__file__), "backend")

    if not args.no_browser:
        def open_browser():
            time.sleep(3)
            webbrowser.open(f"http://localhost:{args.port}")
        import threading
        threading.Thread(target=open_browser, daemon=True).start()

    subprocess.run(
        [sys.executable, "-m", "uvicorn", "main:app",
         "--host", "0.0.0.0", "--port", str(args.port), "--reload"],
        cwd=backend_dir,
        env=os.environ.copy(),
    )

if __name__ == "__main__":
    main()

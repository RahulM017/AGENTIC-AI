#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quick smoke-test script for the University Academic Assistant RAG pipeline.
Tests embedding, retrieval, and optionally the full pipeline with Gemini.

Usage:
  cd d:\\prompt\\uni-assistant
  python test_rag.py
"""

import os
import sys

# Force UTF-8 output on Windows
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Must be run from root of uni-assistant
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))

def test_rag_pipeline():
    print("\n" + "="*55)
    print("  University Academic Assistant -- RAG Pipeline Test")
    print("="*55)

    print("\n[1/4] Importing RAG engine...")
    try:
        from main import UniversityRAGEngine, DATA_DIR, CHROMA_DIR
        print("  [OK] Import successful")
    except Exception as e:
        print(f"  [FAIL] Import failed: {e}")
        import traceback; traceback.print_exc()
        sys.exit(1)

    print("\n[2/4] Initializing engine (loading embedding model)...")
    try:
        engine = UniversityRAGEngine()
        engine.initialize()
        print("  [OK] Engine initialized")
    except Exception as e:
        print(f"  [FAIL] Init failed: {e}")
        import traceback; traceback.print_exc()
        sys.exit(1)

    print("\n[3/4] Ingesting documents...")
    try:
        result = engine.ingest_directory(DATA_DIR)
        print(f"  [OK] Ingested: {result.documents_indexed} docs, {result.chunks_created} chunks")
    except Exception as e:
        print(f"  [FAIL] Ingest failed: {e}")
        import traceback; traceback.print_exc()
        sys.exit(1)

    print("\n[4/4] Running retrieval tests...")
    test_queries = [
        ("What is the minimum GPA for good academic standing?", "2.0"),
        ("What happens if I miss 30% of classes?", "DN"),
        ("When does Fall 2024 semester start?", "August 26"),
        ("What is the maximum Pell Grant?", "7,395"),
        ("How long do I have to submit a grade review?", "10 working days"),
    ]

    all_pass = True
    for query, expected_keyword in test_queries:
        chunks = engine.retrieve(query)
        if chunks:
            combined = " ".join(c["text"] for c in chunks)
            found = expected_keyword.lower() in combined.lower()
            status = "[PASS]" if found else "[WARN]"
            print(f"  {status} Q: {query[:55]}")
            print(f"         Top score: {chunks[0]['relevance_score']:.3f} | Chunks: {len(chunks)}")
            if not found:
                all_pass = False
                print(f"         [WARN] Expected '{expected_keyword}' not found in retrieved text")
        else:
            print(f"  [FAIL] No results for: {query}")
            all_pass = False

    print("\n" + "="*55)
    if all_pass:
        print("  All tests PASSED!")
    else:
        print("  Some tests had warnings -- check retrieval quality")

    # Test status endpoint
    print("\n[Bonus] Testing get_status()...")
    status = engine.get_status()
    print(f"  Status: {status.status}")
    print(f"  Documents: {status.documents_count}")
    print(f"  Chunks: {status.chunks_count}")
    print(f"  API configured: {status.api_configured}")

    # Test LLM if API key present
    api_key = os.environ.get("GEMINI_API_KEY")
    if api_key:
        print("\n[Bonus] Testing full LLM pipeline...")
        try:
            response = engine.answer("What is the minimum GPA to be in good academic standing?")
            print(f"  [OK] LLM response received ({len(response.answer)} chars)")
            print(f"  Confidence: {response.confidence}")
            print(f"  Sources: {[s['source'] for s in response.sources]}")
            preview = response.answer[:300].replace('\n', ' ')
            print(f"\n  Answer preview:\n  {preview}...")
        except Exception as e:
            print(f"  [FAIL] LLM test failed: {e}")
            import traceback; traceback.print_exc()
    else:
        print("\n  [INFO] Set GEMINI_API_KEY to test LLM generation.")

    print("\n[DONE] Test complete. You can now run: python start.py\n")

if __name__ == "__main__":
    test_rag_pipeline()
